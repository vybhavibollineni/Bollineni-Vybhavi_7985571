SELECT
    registration_date,
    COUNT(user_id) AS total_users
FROM Users
GROUP BY registration_date
ORDER BY registration_date DESC;