SELECT
    e.event_id,
    e.title,
    ROUND(AVG(f.rating), 2) AS average_rating,
    COUNT(f.feedback_id) AS total_feedbacks
FROM Events e
LEFT JOIN Feedback f
ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
ORDER BY average_rating DESC;