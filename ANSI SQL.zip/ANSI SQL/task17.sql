SELECT
    resource_type,
    COUNT(*) AS total_resources
FROM Resources
GROUP BY resource_type;