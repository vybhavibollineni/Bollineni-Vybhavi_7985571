import java.io.*;
import java.net.*;

public class task35 {

    public static void main(String[] args) {

        // Server Thread
        new Thread(() -> {
            try {
                ServerSocket server = new ServerSocket(5000);
                Socket socket = server.accept();

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));

                PrintWriter out = new PrintWriter(
                        socket.getOutputStream(), true);

                System.out.println("Client: " + in.readLine());

                out.println("Hello from Server");

                socket.close();
                server.close();

            } catch (Exception e) {
                System.out.println(e);
            }
        }).start();

        // Client
        try {
            Thread.sleep(1000);

            Socket socket = new Socket("localhost", 5000);

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            PrintWriter out = new PrintWriter(
                    socket.getOutputStream(), true);

            out.println("Hello Server");

            System.out.println("Server: " + in.readLine());

            socket.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}