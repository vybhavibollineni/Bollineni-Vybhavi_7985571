import java.util.ArrayList;
import java.util.Collections;

public class task27 {
    public static void main(String[] args) {

        ArrayList<String> list = new ArrayList<>();

        list.add("Ravi");
        list.add("Asha");
        list.add("Kiran");

        Collections.sort(list, (a, b) -> a.compareTo(b));

        System.out.println("Sorted List:");

        for (String name : list) {
            System.out.println(name);
        }
    }
}