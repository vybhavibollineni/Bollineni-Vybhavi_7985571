public class task38 {
    private String name;

    public task38(String name) {
        this.name = name;
    }

    public void display() {
        System.out.println("Name: " + name);
    }

    public int add(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {

        task38 obj = new task38("Vybhavi");

        obj.display();

        int result = obj.add(10, 20);

        System.out.println("Sum = " + result);
    }
}