CREATE DATABASE testdb;
USE testdb;
CREATE TABLE student (
    id INT,
    name VARCHAR(50)
);
INSERT INTO student VALUES
(1,'Ram'),
(2,'Sita');