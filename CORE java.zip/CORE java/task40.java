public class task40 {

    public static void main(String[] args) {

        for (int i = 1; i <= 10; i++) {

            int num = i;

            Thread.startVirtualThread(() -> {
                System.out.println(
                    "Virtual Thread " + num + " Running"
                );
            });
        }

        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}