class task6 {
    public static void main(String[] args) {

        int a = 10;
        float b = 5.5f;
        double c = 20.25;
        char d = 'A';
        boolean e = true;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
    }
}
