
import java.sql.*;
public class task32{

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/testdb";
        String user = "root";
        String password = "root";

        try {
            Connection con =
                    DriverManager.getConnection(url, user, password);

            // Insert Record
            String insertQuery =
                    "INSERT INTO student(id,name) VALUES(?,?)";

            PreparedStatement ps1 =
                    con.prepareStatement(insertQuery);

            ps1.setInt(1, 3);
            ps1.setString(2, "Ravi");

            ps1.executeUpdate();
            System.out.println("Record Inserted");

            // Update Record
            String updateQuery =
                    "UPDATE student SET name=? WHERE id=?";

            PreparedStatement ps2 =
                    con.prepareStatement(updateQuery);

            ps2.setString(1, "Krishna");
            ps2.setInt(2, 3);

            ps2.executeUpdate();
            System.out.println("Record Updated");

            con.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}