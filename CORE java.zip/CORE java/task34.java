
class Utility {
    public static void showMessage() {
        System.out.println("Hello from Utility Module");
    }
}

public class task34 {
    public static void main(String[] args) {
        Utility.showMessage();
    }
}