class task8 {
    public static void main(String[] args) {

        double d = 10.5;
        int a = (int)d;

        int b = 20;
        double c = (double)b;

        System.out.println(a);
        System.out.println(c);
    }
}