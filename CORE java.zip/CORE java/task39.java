import java.lang.reflect.Method;
public class task39 {
    public static void main(String[] args) throws Exception {

        Class<?> cls = Class.forName("Student");

        Object obj = cls.getDeclaredConstructor().newInstance();

        Method[] methods = cls.getDeclaredMethods();

        for (Method m : methods) {
            System.out.println("Method: " + m.getName());
        }

        Method method = cls.getDeclaredMethod("display");

        method.invoke(obj);
    }
}